package com.aml.controlleer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.web.bind.annotation.RestController;

import com.aml.entity.AML_Dao;
import com.aml.exception.DataNotFoundException;
import com.aml.service.AML_Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
@RequestMapping("/report")
public class Controller {

	@Autowired
	AML_Service service;
	
	
	
	@Bean(name="entityManagerFactory")
	public LocalSessionFactoryBean sessionFactory() {
	    LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();

	    return sessionFactory;
	} 
	
	@GetMapping("/total-amount-processed")
	@Produces(MediaType.APPLICATION_JSON)
	public Map<String, Object> getByAllFiles(@RequestBody AML_Dao Data) throws DataNotFoundException {
		
		return service.TotalAmount_AllFiles(Data);
	}
	
	
	
	@GetMapping("/list-of-currency-total-amount")
	@Produces(MediaType.APPLICATION_JSON)
	public String getByList(@RequestBody AML_Dao Data) throws DataNotFoundException {
		return service.Currencies_TotalAmounts();
		
	}
	
	@GetMapping("/total-amount-processed-per-country")
	@Produces(MediaType.APPLICATION_JSON)
	public String getByCountry(@RequestBody AML_Dao Data) throws DataNotFoundException {
		
		return service.TotalAmount_Country();
	}

}
