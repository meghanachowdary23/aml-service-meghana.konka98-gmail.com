package com.aml.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.aml.entity.AML_Dao;

@Repository
public interface AML_Repository2 extends CrudRepository<AML_Dao, String> {

}
