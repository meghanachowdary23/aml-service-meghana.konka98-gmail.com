package com.aml.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOError;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.aml.Repository.AML_Repository1;
import com.aml.Repository.AML_Repository2;
import com.aml.date.util.AML_Date_Util;
import com.aml.entity.AML_Dao;
import com.aml.exception.DataNotFoundException;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.CSVReader;

import reactor.core.publisher.Mono;



@Service
public class AML_Service {

	static Map<String, Object> AML_LIST;
	static {
		AML_LIST = new LinkedHashMap<>();
	}
	
	@Autowired
	public AML_Repository1 Repository1;
	
	@Autowired
	public AML_Repository2 Repository2;
	
	@Autowired
	public AML_Date_Util Date;
	
	private final WebClient webClient;

	public AML_Service(WebClient.Builder webClientBuilder) {
		this.webClient = webClientBuilder.baseUrl("http://localhost:8080").build();
	}

	public Mono<String> someRestCall(String name) {
		return this.webClient.get().uri("/report/total-amount-processed", name)
						.retrieve().bodyToMono(String.class);
	}
	
	@SuppressWarnings("unchecked")
	@POST
	@Consumes({MediaType.APPLICATION_JSON})
	public void JSONFile() throws IOException {
		InputStream getLocalJsonFile = new FileInputStream("resources/payment-files/json-payments/PaymentMessages.json");

        AML_LIST = new ObjectMapper().readValue(getLocalJsonFile, HashMap.class);
        
	
	    }

	    @POST
		@Consumes({MediaType.APPLICATION_XML})
	public void XMLFile() throws IOException {
		
	    File xmlFile = new File("resources/payment-files/json-payments/PaymentMessage1.xml");
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();
            
            NodeList nodeList = doc.getElementsByTagName("UrnMetadata");
            List < AML_Dao > Metadata = new ArrayList < AML_Dao > ();

            for (int i = 0; i < nodeList.getLength(); i++) {
            	Metadata.add(getUrnMetadata(nodeList.item(i)));
            }
            // lets print User list information
            for (AML_Dao data: Metadata) {
                
            	float array = (float) data.getAmount();
            	
            }
        } catch (SAXException | ParserConfigurationException | IOException e1) {
            e1.printStackTrace();
        }

    }

    private static AML_Dao getUrnMetadata(Node node) {
        // XMLReaderDOM domReader = new XMLReaderDOM();
    	AML_Dao UrnMetadata = new AML_Dao();
        if (node.getNodeType() == Node.ELEMENT_NODE) {
            Element element = (Element) node;
            UrnMetadata.setCountry(getTagValue("country", element));
            UrnMetadata.setAmount(Integer.parseInt(getTagValue("amount", element)));
            UrnMetadata.setCurrency(getTagValue("currency", element));
          
        }
        return UrnMetadata;
    }

    private static String getTagValue(String tag, Element element) {
        NodeList nodeList = element.getElementsByTagName(tag).item(0).getChildNodes();
        Node node = (Node) nodeList.item(0);
        return node.getNodeValue();
        
    }

	
	@POST
	@Consumes({"text/plain"})
	public void CSVFile() throws IOException {

		List<List<String>> records = new ArrayList<List<String>>();
		try (CSVReader csvReader = new CSVReader(new FileReader("resources/payment-files/json-payments/PaymentMessage.csv"));) {
		    String[] values = null;
		    while ((values = csvReader.readNext()) != null) {
		        records.add(Arrays.asList(values));
		    }
		    //float[] array =  
		}catch(IOError e) {
			e.printStackTrace();
	    }
		
		}
	
	
	public Map<String, Object> TotalAmount_AllFiles(AML_Dao Data) throws DataNotFoundException {
			
			return AML_LIST;
	
		}
	
	public String Currencies_TotalAmounts() throws DataNotFoundException {
		return null;
		
		//return Data.getCurrency()+":"+Data.getAmount();
	}
	
	public String TotalAmount_Country() throws DataNotFoundException {
		
		return null;
		//return Data.getCountry()+":"+Data.getAmount();
	}
	
	
	
	}
	
	
	
	

