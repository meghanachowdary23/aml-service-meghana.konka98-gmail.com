package com.aml.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;


@AllArgsConstructor
@NoArgsConstructor

@JsonIgnoreProperties(ignoreUnknown = true)
@Entity
@Table(name="AML_DB")
public class AML_Dao {
	
	@Id
	private String country;
	@Column
	private float amount;
	@Column
	private String reference;
	@Column
	private String currency;
	@Column
	private String methodOfPayment;
	@Column
	private String remittanceInfo;
	@Column
	private String paymentProcessor;
	@Column
	private String date;
	
	
	

	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getReference() {
		return reference;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getMethodOfPayment() {
		return methodOfPayment;
	}
	public void setMethodOfPayment(String methodOfPayment) {
		this.methodOfPayment = methodOfPayment;
	}
	public String getRemittanceInfo() {
		return remittanceInfo;
	}
	public void setRemittanceInfo(String remittanceInfo) {
		this.remittanceInfo = remittanceInfo;
	}
	public String getPaymentProcessor() {
		return paymentProcessor;
	}
	public void setPaymentProcessor(String paymentProcessor) {
		this.paymentProcessor = paymentProcessor;
	}
	
	 @Override
	  public String toString() {
	    return "Total_Amount_Processed:{" +
	        "Date=" + date +
	        ",Total='" + amount + '\'' +
	        '}';
	  }
	
	
	
	
}
