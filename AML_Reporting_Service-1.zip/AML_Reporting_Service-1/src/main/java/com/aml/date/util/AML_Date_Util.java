package com.aml.date.util;

public class AML_Date_Util {

	public static String getCurrentTime() {
		return String.valueOf(System.currentTimeMillis());
	}
}
