DROP TABLE IF EXISTS AML_DATABASE;
create table AML_DATABASE(
	country VARCHAR(50) NOT NULL,
	amount FLOAT(25) NOT NULL,
	reference VARCHAR(50) NOT NULL,
	currency VARCHAR(50) NOT NULL,
	methodOfPayment VARCHAR(50) NOT NULL,
	remittanceInfo VARCHAR(50) NOT NULL,
	paymentProcessor VARCHAR(50) NOT NULL,
);